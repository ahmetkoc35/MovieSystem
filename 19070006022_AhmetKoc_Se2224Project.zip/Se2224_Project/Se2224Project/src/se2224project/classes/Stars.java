/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package se2224project.classes;

/**
 *
 * @author Excalibur
 */
public class Stars {
    
    int movieId;
    String movieTitle;
    int movieYear;
    String nameSurname;

    public Stars(int movieId, String movieTitle, int movieYear, String nameSurname) {
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.movieYear = movieYear;
        this.nameSurname = nameSurname;
    }
}
