/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package se2224project.classes;

/**
 *
 * @author Excalibur
 */
public class Movies {
    
    int movieId;
    String title;
    int year;
    int length;
    String genre;
    String studioName;
    String producersName;
    String shortDescription;
    Double avgRating;
    int numWatched;

    public Movies(int movieId, String title, int year, int length, 
                  String genre, String studioName, String producersName, 
                  String shortDescription, Double avgRating, int numWatched) {
        this.movieId = movieId;
        this.title = title;
        this.year = year;
        this.length = length;
        this.genre = genre;
        this.studioName = studioName;
        this.producersName = producersName;
        this.shortDescription = shortDescription;
        this.avgRating = avgRating;
        this.numWatched = numWatched;
    }
}
